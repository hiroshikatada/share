# Parser Foundation

## Files

- `lexer.js`
- `token_reader.js`
- `test_token_reader.js`

## Position policy

`TokenReader` internally uses JavaScript array indexes.

All public position information uses `token_seq`.

Examples:

```javascript
const sumToken = reader.findForward("SUM");

const closeToken = reader.findMatchingCloseParenthesis(
  openToken.token_seq
);

const expressionTokens = reader.sliceByTokenSeq(
  sumToken.token_seq,
  closeToken.token_seq
);
```

## Run

```bash
node test_token_reader.js
```
