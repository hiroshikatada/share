"use strict";

/**
 * SQL文字列をToken配列へ変換する。
 *
 * depth仕様:
 *
 *   SUM(amount)
 *
 *   SUM     depth 0
 *   (       depth 0
 *   amount  depth 1
 *   )       depth 0
 *
 * @param {string} sqlText
 * @returns {Array<object>}
 */
function tokenize(sqlText) {
  if (typeof sqlText !== "string") {
    throw new TypeError("tokenize: sqlText must be a string.");
  }

  const tokens = [];

  let tokenSeq = 0;
  let line = 1;
  let column = 1;
  let parenDepth = 0;
  let index = 0;

  const KEYWORDS = new Set([
    "SELECT", "FROM", "WHERE", "GROUP", "BY", "HAVING", "QUALIFY",
    "ORDER", "LIMIT", "JOIN", "LEFT", "RIGHT", "FULL", "INNER",
    "OUTER", "CROSS", "ON", "USING", "WITH", "RECURSIVE", "AS",
    "UNION", "ALL", "DISTINCT", "AND", "OR", "NOT", "IN", "IS",
    "NULL", "TRUE", "FALSE", "CASE", "WHEN", "THEN", "ELSE", "END",
    "OVER", "PARTITION", "UNNEST", "STRUCT", "ARRAY", "EXCEPT",
    "REPLACE", "INTERSECT", "OFFSET", "ORDINAL", "ASC", "DESC",
    "ROWS", "RANGE", "GROUPS", "NULLS", "FIRST", "LAST", "BETWEEN",
    "PRECEDING", "FOLLOWING", "CURRENT", "ROW"
  ]);

  const SYMBOLS = new Set(["(", ")", ",", ".", ";", "[", "]"]);
  const SINGLE_OPERATORS = new Set(["=", "+", "-", "*", "/", "%", "<", ">", "!"]);
  const DOUBLE_OPERATORS = new Set([">=", "<=", "!=", "<>", "||"]);

  function pushToken(token, normalizedToken, tokenType, tokenLine, tokenColumn) {
    tokens.push({
      token_seq: ++tokenSeq,
      line_no: tokenLine,
      column_no: tokenColumn,
      token,
      normalized_token: normalizedToken,
      token_type: tokenType,
      paren_depth: parenDepth
    });
  }

  function isSpace(character) {
    return /\s/.test(character);
  }

  function isIdentifierStart(character) {
    return /[A-Za-z_]/.test(character);
  }

  function isIdentifierPart(character) {
    return /[A-Za-z0-9_$]/.test(character);
  }

  function isDigit(character) {
    return /[0-9]/.test(character);
  }

  function advanceCharacter(character) {
    if (character === "\n") {
      line++;
      column = 1;
    } else {
      column++;
    }

    index++;
  }

  while (index < sqlText.length) {
    const character = sqlText[index];

    if (isSpace(character)) {
      advanceCharacter(character);
      continue;
    }

    const startLine = line;
    const startColumn = column;

    if (character === "-" && sqlText[index + 1] === "-") {
      let value = "";

      while (index < sqlText.length && sqlText[index] !== "\n") {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);
      }

      pushToken(value, value, "COMMENT", startLine, startColumn);
      continue;
    }

    if (character === "/" && sqlText[index + 1] === "*") {
      let value = "";

      while (index < sqlText.length) {
        const current = sqlText[index];

        value += current;

        if (current === "*" && sqlText[index + 1] === "/") {
          advanceCharacter(current);

          const closingSlash = sqlText[index];
          value += closingSlash;
          advanceCharacter(closingSlash);
          break;
        }

        advanceCharacter(current);
      }

      pushToken(value, value, "COMMENT", startLine, startColumn);
      continue;
    }

    if (character === "`") {
      let value = character;

      advanceCharacter(character);

      while (index < sqlText.length) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);

        if (current === "`") {
          break;
        }
      }

      const normalizedValue = value.length >= 2
        ? value.substring(1, value.length - 1)
        : value;

      pushToken(
        value,
        normalizedValue,
        "BACKTICK_IDENTIFIER",
        startLine,
        startColumn
      );

      continue;
    }

    if (character === "'" || character === '"') {
      const quoteCharacter = character;
      let value = character;

      advanceCharacter(character);

      while (index < sqlText.length) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);

        if (current === quoteCharacter && sqlText[index] === quoteCharacter) {
          const escapedQuote = sqlText[index];

          value += escapedQuote;
          advanceCharacter(escapedQuote);
          continue;
        }

        if (current === quoteCharacter) {
          break;
        }
      }

      const normalizedValue = value.length >= 2
        ? value.substring(1, value.length - 1)
        : value;

      pushToken(value, normalizedValue, "STRING", startLine, startColumn);
      continue;
    }

    if (isIdentifierStart(character)) {
      let value = "";

      while (index < sqlText.length && isIdentifierPart(sqlText[index])) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);
      }

      const normalizedValue = value.toUpperCase();
      const tokenType = KEYWORDS.has(normalizedValue) ? "KEYWORD" : "IDENTIFIER";

      pushToken(value, normalizedValue, tokenType, startLine, startColumn);
      continue;
    }

    if (isDigit(character)) {
      let value = "";

      while (index < sqlText.length && /[0-9.]/.test(sqlText[index])) {
        const current = sqlText[index];

        value += current;
        advanceCharacter(current);
      }

      pushToken(value, value, "NUMBER", startLine, startColumn);
      continue;
    }

    const twoCharacters = sqlText.substring(index, index + 2);

    if (DOUBLE_OPERATORS.has(twoCharacters)) {
      pushToken(twoCharacters, twoCharacters, "OPERATOR", startLine, startColumn);

      advanceCharacter(sqlText[index]);
      advanceCharacter(sqlText[index]);
      continue;
    }

    if (SYMBOLS.has(character)) {
      // 閉じ括弧は外側のdepthへ戻してから保存する。
      if (character === ")" || character === "]") {
        parenDepth--;

        if (parenDepth < 0) {
          throw new SyntaxError(
            `tokenize: unexpected closing symbol "${character}" ` +
            `at line ${startLine}, column ${startColumn}.`
          );
        }
      }

      pushToken(character, character, "SYMBOL", startLine, startColumn);

      // 開き括弧は保存後、次のTokenからdepthを上げる。
      if (character === "(" || character === "[") {
        parenDepth++;
      }

      advanceCharacter(character);
      continue;
    }

    if (SINGLE_OPERATORS.has(character)) {
      pushToken(character, character, "OPERATOR", startLine, startColumn);
      advanceCharacter(character);
      continue;
    }

    pushToken(character, character, "UNKNOWN", startLine, startColumn);
    advanceCharacter(character);
  }

  if (parenDepth !== 0) {
    throw new SyntaxError(
      `tokenize: unclosed parenthesis or bracket. Remaining depth: ${parenDepth}.`
    );
  }

  return tokens;
}

module.exports = {
  tokenize
};
