# PARTIAL_FAILURE diagnostic package

## File to execute

`sql/pipeline/03_run_daily_lineage_pipeline_debug.sql`

This is a diagnostic variant of the production daily pipeline.

When the lineage UDF returns `PARTIAL_FAILURE` or another non-publishable status, it:

1. preserves the last known-good rows in `lineage_direct_dependency`;
2. saves the UDF-provided diagnostics in `lineage_diagnostic`;
3. adds `UDF_RESULT_NOT_PUBLISHABLE`;
4. leaves the definition as `FAILED` and `is_changed = TRUE`;
5. displays the diagnostics as a BigQuery result set.

The production file `sql/pipeline/03_run_daily_lineage_pipeline.sql` remains unchanged.

## After execution

Filter `lineage_diagnostic` for:

- `v_customer_primary_contact`
- severity `ERROR` or `WARNING`

Use the diagnostic code, engine stage and message to determine the parser or resolver correction.

## Optional isolated test

`sql/pipeline/debug_v_customer_primary_contact.sql` runs only the target View without updating repository tables. Its environment defaults may need to be aligned with the production configuration.
