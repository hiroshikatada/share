# BDE Lineage GCS UDF v1

BigQuery JavaScript UDFの本文サイズ制限を避けるため、解析エンジン本体をCloud Storage上の外部JavaScriptライブラリとして読み込む最小構成です。

## 構成

```text
bde_lineage_gcs_udf_v1/
├── README.md
├── build/
│   └── lineage_udf_bundle.js
└── bigquery/
    ├── create_persistent_lineage_udf.sql
    ├── test_persistent_lineage_udf.sql
    ├── create_lineage_tables.sql
    ├── create_pipeline_tables.sql
    ├── load_physical_columns.sql
    ├── run_single_view_analysis.sql
    ├── publish_staged_analysis.sql
    └── run_dataset_views_analysis.sql
```

## 導入手順

### 1. bundleをGCSへアップロード

Google Cloud Consoleで、次のファイルを任意のBucketへ手動アップロードします。

```text
build/lineage_udf_bundle.js
```

例:

```text
gs://my-lineage-bucket/bde-lineage/lineage_udf_bundle.js
```

同名ファイルを更新した場合は、BigQuery側で反映確認しやすいよう、必要に応じてファイル名にバージョンを付けてください。

### 2. GCSの参照権限を確認

UDFを作成・実行する利用者が、対象オブジェクトを読み取れるようにします。
最低限、対象ファイルに対する `storage.objects.get` が必要です。
通常はBucketへ `Storage Object Viewer` を付与すると分かりやすいです。

### 3. 永続UDF作成SQLを書き換える

`bigquery/create_persistent_lineage_udf.sql` の次を変更します。

```text
YOUR_PROJECT
YOUR_DATASET
gs://YOUR_BUCKET/YOUR_PATH/lineage_udf_bundle.js
```

例:

```sql
CREATE OR REPLACE FUNCTION
  `my-project.lineage.analyze_lineage_json`(...)
...
OPTIONS (
  library = [
    'gs://my-lineage-bucket/bde-lineage/lineage_udf_bundle.js'
  ]
)
```

### 4. 永続UDFを作成

BigQueryコンソールで次を実行します。

```text
bigquery/create_persistent_lineage_udf.sql
```

SQLへ埋め込むJavaScriptは入口部分だけなので、本文32KB制限には該当しません。

### 5. 疎通テスト

`bigquery/test_persistent_lineage_udf.sql` の `YOUR_PROJECT` と `YOUR_DATASET` を変更して実行します。
JSON文字列が返れば、GCSライブラリの読み込みとUDF呼び出しは成功です。

### 6. パイプラインを実行

必要な識別子を各SQL内で変更し、次の順番で実行します。

```text
1. create_lineage_tables.sql
2. create_pipeline_tables.sql
3. load_physical_columns.sql
4. run_single_view_analysis.sql
5. publish_staged_analysis.sql
```

データセット全体のViewを解析する段階では、次を使用します。

```text
run_dataset_views_analysis.sql
```

## よくあるエラー

### Library not found / Access Denied

- GCS URIのBucket名、パス、ファイル名を確認します。
- UDFを作成・実行するアカウントにGCSオブジェクトの閲覧権限があるか確認します。

### analyzeLineageForBigQuery is not defined

- アップロードしたファイルが `build/lineage_udf_bundle.js` であることを確認します。
- 古いbundleや別ファイルをアップロードしていないか確認します。

### Definition body too long

- 古いインライン版 `create_persistent_lineage_udf.sql` を実行していないか確認します。
- このZIPに含まれるGCS版SQLでは、JavaScript本体をSQL内へ埋め込みません。
