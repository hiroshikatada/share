WITH base_sales AS (
  SELECT
    customer_id,
    amount,
    sales_date,
    status
  FROM `project.dataset.sales`
  WHERE status = 'COMPLETE'
),

customer_sales AS (
  SELECT
    customer_id,
    SUM(amount) AS total_amount,
    MAX(sales_date) AS last_sales_date
  FROM base_sales
  GROUP BY customer_id
)

SELECT
  cs.customer_id,
  cs.total_amount,
  cs.last_sales_date,

  (
    SELECT
      MAX(o.order_date)
    FROM `project.dataset.orders` AS o
    WHERE
      o.customer_id = cs.customer_id
  ) AS last_order_date

FROM customer_sales AS cs

QUALIFY
  ROW_NUMBER() OVER (
    PARTITION BY cs.customer_id
    ORDER BY cs.last_sales_date DESC
  ) = 1;
