"use strict";

const fs = require("fs");
const path = require("path");

const {
  parseDependenciesPhysical
} = require("./bde_physical_lineage");

const sqlText = fs.readFileSync(
  path.join(__dirname, "sample_physical_lineage.sql"),
  "utf8"
);

const dependencies =
  parseDependenciesPhysical(sqlText);

console.table(
  dependencies.map(
    (dependency) => ({
      dependency_seq:
        dependency.dependency_seq,
      output_column:
        dependency.output_column,
      usage_type:
        dependency.usage_type,
      immediate_source_name:
        dependency.immediate_source_name,
      immediate_source_column:
        dependency.immediate_source_column,
      source_name:
        dependency.source_name,
      source_column:
        dependency.source_column,
      lineage_path:
        dependency.lineage_path,
      expansion_status:
        dependency.expansion_status,
      resolution_status:
        dependency.resolution_status
    })
  )
);
