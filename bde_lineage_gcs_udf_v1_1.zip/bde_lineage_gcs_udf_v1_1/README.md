# BDE Lineage GCS UDF v1.1

BigQuery JavaScript UDFの本体をGCSから読み込む、検証用の最小構成です。

## v1.1の変更点

1. SELECTリスト末尾のカンマをBigQueryの正常な構文として扱います。
2. UDF戻り値を次のJSON構造に統一しました。

```json
{
  "analysis": { "analysis_id": "...", "analysis_status": "..." },
  "exported_tables": {
    "tokens": [],
    "lineage_paths": [],
    "diagnostics": []
  }
}
```

3. `publish_staged_analysis.sql`を上記JSON構造に対応させました。
4. `run_single_view_analysis.sql`と`run_dataset_views_analysis.sql`のstatus取得パスを修正しました。

## 更新手順

1. `build/lineage_udf_bundle.js`を、v1と同じGCSパスへ上書きアップロードします。
2. `bigquery/create_persistent_lineage_udf.sql`を再実行します。
3. `bigquery/run_single_view_analysis.sql`を再実行し、新しいanalysis_idを取得します。
4. `bigquery/validate_staged_json_v1_1.sql`でJSON構造を確認します。
5. `bigquery/publish_staged_analysis.sql`に新しいanalysis_idを設定して実行します。

既存のv1 staging行はJSON構造が異なるため、v1.1のpublish SQLではなく、View解析を再実行して新しいstaging行を作ることを推奨します。
